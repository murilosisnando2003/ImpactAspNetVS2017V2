﻿namespace Pessoal.Dominio
{
    public enum Prioridade
    {
        Alta = 1,
        Media = 2,
        Baixa = 3
    }
}