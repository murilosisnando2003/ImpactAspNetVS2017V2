﻿namespace Oficina.Dominio
{
    public enum Combustivel //: int
    {
        Gasolina = 1,
        Alcool = 2,
        Flex = 3,
        Diesel = 4,
        Gnv = 5
    }
}