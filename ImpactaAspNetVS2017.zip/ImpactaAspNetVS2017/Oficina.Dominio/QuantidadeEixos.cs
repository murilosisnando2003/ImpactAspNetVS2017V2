﻿namespace Oficina.Dominio
{
    public enum QuantidadeEixos
    {
        Dois = 2,
        Tres  = 3,
        Quatro = 4
    }
}