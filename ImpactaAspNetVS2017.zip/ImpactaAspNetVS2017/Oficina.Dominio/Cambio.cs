﻿namespace Oficina.Dominio
{
    public enum Cambio
    {
        Manual = 1,
        Automatico = 2,
        Automatizado = 3,
        Cvt =4
    }
}