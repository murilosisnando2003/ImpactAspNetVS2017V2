﻿namespace Oficina.Dominio
{
    public enum TipoCarroceria
    {
        Hatch = 1,
        Sedan = 2,
        Pickup = 3
    }
}