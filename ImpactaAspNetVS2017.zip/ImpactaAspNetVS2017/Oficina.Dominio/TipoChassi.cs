﻿namespace Oficina.Dominio
{
    public enum TipoChassi
    {
        Scooter = 1,
        Street = 2,
        Speed = 3,
        BigTrail = 4
    }
}