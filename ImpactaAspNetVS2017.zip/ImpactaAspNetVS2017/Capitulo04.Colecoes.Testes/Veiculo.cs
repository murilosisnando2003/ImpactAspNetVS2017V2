﻿namespace Capitulo04.Colecoes.Testes
{
    internal class Veiculo
    {
    }
}